$(function () {
  $('.slider__carousel').slick({
    prevArrow: '<button type="button" class="slick-prev"><img src="images/arrow-left.svg" alt="стрелка влево"></button>',
    nextArrow: '<button type="button" class="slick-next"><img src="images/arrow-right.svg" alt="стрелка вправо"></button>'
  });
})